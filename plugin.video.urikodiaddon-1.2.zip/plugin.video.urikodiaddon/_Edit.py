import xbmcaddon

MainBase = 'http://pastebin.com/raw/htaCKUUK'
addon = xbmcaddon.Addon('plugin.video.urikodiaddon')